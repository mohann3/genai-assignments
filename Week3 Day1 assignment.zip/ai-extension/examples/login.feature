Feature: User Login and Dashboard Access

  Description: Test user authentication and dashboard access
  After successful login, user should be able to view their dashboard

  Scenario Outline: Successful login with valid credentials
    Given I open the login page
    When I type "<username>" into the Username field
    And I type "<password>" into the Password field
    And I click the Login button
    Then I should be logged in successfully
    And I should be redirected to the dashboard

    Examples:
      | username        | password     |
      | "ravi.kumar"    | "Test@1234"  |
      | "admin@work.in" | "Admin@2024" |
      | "user.testleaf" | "Pass@0987"  |

  Scenario: Login fails with invalid credentials
    Given I open the login page
    When I type "invalid.user" into the Username field
    And I type "wrongpassword" into the Password field
    And I click the Login button
    Then I should see an error message
    And I should remain on the login page

  Scenario: Remember me functionality works
    Given I open the login page
    When I type "ravi.kumar" into the Username field
    And I type "Test@1234" into the Password field
    And I check the Remember Me checkbox
    And I click the Login button
    Then I should be logged in successfully
    And the Remember Me preference should be saved

  Scenario: Forgot password link navigates correctly
    Given I open the login page
    When I click the Forgot Password link
    Then I should be redirected to the password reset page

  Scenario Outline: Case sensitivity in password field
    Given I open the login page
    When I type "<username>" into the Username field
    And I type "<password>" into the Password field
    And I click the Login button
    Then login result should be "<result>"

    Examples:
      | username    | password    | result  |
      | "admin"     | "Test@1234" | "fail"  |
      | "admin"     | "test@1234" | "fail"  |
      | "admin"     | "TEST@1234" | "fail"  |
