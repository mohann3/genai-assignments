# Playwright TypeScript Support

This AI code generator extension now supports **Playwright TypeScript** alongside the existing **Selenium Java** implementation.

## Supported Frameworks

### 1. Selenium Java (Existing)
- **Language**: Java
- **Engine**: Selenium
- **Generates:**
  - Selenium Java Page Object Classes
  - Cucumber Feature Files (Gherkin)
  - Feature Files + Java Step Definitions

### 2. Playwright TypeScript (New)
- **Language**: TypeScript
- **Engine**: Playwright
- **Generates:**
  - Playwright TypeScript Page Object Classes
  - Cucumber Feature Files (Gherkin)
  - Feature Files + TypeScript Step Definitions

---

## How to Use

### Step 1: Select Framework
In the **Code Generator** tab, choose your framework:
- **Selenium Java** - For Selenium WebDriver in Java
- **Playwright TS** - For Playwright in TypeScript

### Step 2: Inspect DOM
Click the **Inspect** button and select the elements you want to automate on the target webpage.

### Step 3: Select Code Types
Choose what you want to generate:
- ✅ **Feature File** - Cucumber BDD feature files (Gherkin)
- ✅ **Page Class** - Page Object Model classes

### Step 4: Generate Code
Click **Generate** and the AI will create the automation code in your selected framework.

---

## Generation Patterns

### Pattern 1: Page Object Only
**Selection**: Feature File ☐ Page Class ☑

#### Selenium Java Output:
```java
package com.testleaf.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver driver;
    private WebElement usernameField;
    private WebElement loginButton;
    
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.usernameField = driver.findElement(By.id("username"));
        this.loginButton = driver.findElement(By.xpath("//button[contains(text(),'Login')]"));
    }
    
    public void enterUsername(String username) {
        usernameField.sendKeys(username);
    }
    
    public void clickLogin() {
        loginButton.click();
    }
}
```

#### Playwright TypeScript Output:
```typescript
import { Page, Locator } from '@playwright/test';

export class LoginPage {
    readonly page: Page;
    readonly usernameField: Locator;
    readonly loginButton: Locator;
    
    constructor(page: Page) {
        this.page = page;
        this.usernameField = page.locator('#username');
        this.loginButton = page.locator('button:has-text("Login")');
    }
    
    async enterUsername(username: string) {
        await this.usernameField.fill(username);
    }
    
    async clickLogin() {
        await this.loginButton.click();
    }
}
```

---

### Pattern 2: Feature File Only
**Selection**: Feature File ☑ Page Class ☐

**Output (Same for both frameworks - Gherkin syntax):**
```gherkin
Feature: User Login

Scenario Outline: Successful login with valid credentials
  Given I open the login page
  When I type "<username>" into the Username field
  And I type "<password>" into the Password field
  And I click the Login button
  Then I should be logged in successfully

Examples:
  | username | password  |
  | "admin"  | "admin@1" |
  | "user1"  | "pass123" |
```

---

### Pattern 3: Feature File + Step Definitions (Full Stack)
**Selection**: Feature File ☑ Page Class ☑

#### Selenium Java Output:
```java
package com.leaftaps.stepdefs;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginStepDefinitions {
    private WebDriver driver;
    private WebDriverWait wait;
    
    @Before
    public void setUp() {
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }
    
    @After
    public void tearDown() {
        if (driver != null) driver.quit();
    }
    
    @Given("I open the login page")
    public void openLoginPage() {
        driver.get("https://app.example.com/login");
    }
    
    @When("I type {string} into the Username field")
    public void enterUsername(String username) {
        driver.findElement(By.id("username")).sendKeys(username);
    }
}
```

#### Playwright TypeScript Output:
```typescript
import { Given, When, Then, Before, After } from '@cucumber/cucumber';
import { chromium, Browser, BrowserContext, Page } from '@playwright/test';
import { expect } from '@playwright/test';

let browser: Browser;
let context: BrowserContext;
let page: Page;

Before(async function() {
    browser = await chromium.launch();
    context = await browser.newContext();
    page = await context.newPage();
});

After(async function() {
    await context.close();
    await browser.close();
});

Given('I open the login page', async function() {
    await page.goto('https://app.example.com/login');
});

When('I type {string} into the Username field', async function(username: string) {
    await page.fill('#username', username);
});

When('I type {string} into the Password field', async function(password: string) {
    await page.fill('#password', password);
});

When('I click the Login button', async function() {
    await page.click('button:has-text("Login")');
});

Then('I should be logged in successfully', async function() {
    const userWelcome = await page.locator('.user-welcome');
    await expect(userWelcome).toBeVisible();
});
```

---

## Framework Comparison

| Feature | Selenium Java | Playwright TypeScript |
|---------|---|---|
| **WebDriver Setup** | `WebDriver driver = new ChromeDriver()` | `const browser = await chromium.launch()` |
| **Element Location** | `By.id()`, `By.xpath()` | `page.locator()` |
| **Fill Input** | `sendKeys()` | `fill()` |
| **Click Element** | `click()` | `click()` |
| **Explicit Wait** | Requires `WebDriverWait` | Built-in (auto-waits) |
| **Default Timeout** | Manual setup | 30 seconds (configurable) |
| **Assertions** | Custom + assertions | `expect()` from Playwright |
| **Async Pattern** | Synchronous | Async/Await |

---

## API Providers

Both frameworks support the same LLM providers:
- **Groq** - Fast open-source models
- **OpenAI** - GPT-4, GPT-3.5-Turbo
- **TestLeaf** - Enterprise LLM platform

Configure your API keys in the **Settings** tab.

---

## Best Practices

### For Selenium Java:
- Use Page Object Model (POM) pattern
- Leverage explicit waits for element visibility
- Organize step definitions by feature/functionality
- Use South India realistic test data

### For Playwright TypeScript:
- Use page.locator() with modern selectors
- Leverage Playwright's auto-waits
- Use async/await consistently
- Package.json with TypeScript dev dependencies
- Use `expect()` for assertions

---

## Configuration

### In Settings Tab:

**For Selenium Java:**
- Language Binding: `Java`
- Browser Engine: `Selenium`

**For Playwright TypeScript:**
- Language Binding: `TypeScript`
- Browser Engine: `Playwright`

---

## Example Workflow

1. Open target webpage in browser
2. Click extension icon → Side panel opens
3. Select **Playwright TS** in Code Generator tab
4. Click **Inspect** → Select form elements
5. Check **Feature File** + **Page Class**
6. Add instructions in text area (optional)
7. Click **Generate**
8. Copy generated TypeScript code

---

## Generated Code Structure

### Playwright Project Example:
```
my-playwright-tests/
├── pages/
│   ├── BasePage.ts
│   ├── LoginPage.ts
│   └── DashboardPage.ts
├── features/
│   ├── login.feature
│   └── dashboard.feature
├── step-definitions/
│   ├── login.steps.ts
│   └── dashboard.steps.ts
├── playwright.config.ts
├── package.json
└── tsconfig.json
```

---

## Troubleshooting

### Feature file not generating?
- Ensure **Feature File** checkbox is checked
- Make sure DOM elements are properly selected via Inspector

### Page Object class not generating?
- Ensure **Page Class** checkbox is checked
- Verify that the DOM has sufficient form elements

### API Key error?
- Go to **Settings** tab
- Enter valid API key for your selected provider
- Verify API key has sufficient credits

---

## Future Enhancements

- Support for Cypress TypeScript
- Support for Puppeteer TypeScript
- C# + Selenium integration
- Python + Selenium integration
- Test execution integration
- GitHub integration

---

## Support

For issues or feature requests, please refer to the extension documentation or check the LLM provider status.
